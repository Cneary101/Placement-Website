# MMA Fight Results Tracker

A Python college assignment for recording fighters and completed MMA fights.

## Features

- Add fighters and remove fighters that are not used in saved fights.
- Add, view, edit and delete fight results.
- Search for either fighter by name and combine weight class and method filters.
- Validate required fields, completed-fight dates, different fighters and rounds 1 to 5.
- Keep records between sessions in a local SQLite database through SQLAlchemy ORM.

## Run

Use Python 3.12. From this folder, run:

```text
python -m pip install -r requirements.txt
python MMAFightApplication.py
```

The app creates mma_tracker.db beside the Python file. Keep the folder writable and retain that database to keep your records. To use a virtual environment, create and activate it before installing the requirements.

## How the code is organised

- Fighter and Fight define two database tables. Each fight links to two fighter IDs.
- FightManager handles validation, database sessions, saves, deletes and search queries.
- MainWindow contains the PyQt5 forms, list and button actions.
- SQLite foreign keys and the delete check protect fighters already referenced by fights.

The Python source is the uploaded coursework file, with its filename simplified. Screenshots use fictional demonstration records. No existing database is included in this download.
