import sys
from datetime import date
from pathlib import Path
from sqlalchemy import Date, ForeignKey, Integer, String, create_engine, event, or_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column
from PyQt5.QtCore import QDate
from PyQt5.QtWidgets import (
    QApplication, QComboBox, QDateEdit, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QMainWindow, QMessageBox, QPushButton,
    QSpinBox, QTextEdit, QVBoxLayout, QWidget,
)

# Dropdown Choices (Grouped for interface/validation)
WEIGHTS = ["Strawweight", "Flyweight", "Bantamweight", "Featherweight", "Lightweight",
           "Welterweight", "Middleweight", "Light heavyweight", "Heavyweight", "Catchweight"]
RESULTS = ["Fighter 1 win", "Fighter 2 win", "Draw", "No contest"]
METHODS = ["KO/TKO", "Submission", "Decision", "Disqualification", "Other"]
DATABASE_PATH = Path(__file__).resolve().with_name("mma_tracker.db")


# Table definitions
class Base(DeclarativeBase):
    pass

# Fighter Table
class Fighter(Base):
    __tablename__ = "fighters"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100))
    nationality: Mapped[str] = mapped_column(String(50))

# Fights Table
class Fight(Base):
    __tablename__ = "fights"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    event: Mapped[str] = mapped_column(String(100))
    fight_date: Mapped[date] = mapped_column(Date)
    fighter_1: Mapped[int] = mapped_column(ForeignKey("fighters.id"))
    fighter_2: Mapped[int] = mapped_column(ForeignKey("fighters.id"))
    weight: Mapped[str] = mapped_column(String(30))
    result: Mapped[str] = mapped_column(String(30))
    method: Mapped[str] = mapped_column(String(30))
    round: Mapped[int] = mapped_column(Integer)

# Validation/Sessions
class FightManager:
    def __init__(self, database_path=DATABASE_PATH):
        self.engine = create_engine(f"sqlite:///{database_path}")

        @event.listens_for(self.engine, "connect")
        def enableForeignKeys(connection, connection_record):
            # SQLite configuration only; all record operations use the ORM.
            cursor = connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

        # Create missing tables without deleting existing records.
        Base.metadata.create_all(self.engine)

    def getFighters(self):
        with Session(self.engine) as session:
            return session.scalars(select(Fighter).order_by(Fighter.id)).all()

    def addFighter(self, name, nationality):
        name, nationality = name.strip(), nationality.strip()
        if not name or not nationality:
            raise ValueError("Enter a fighter name and nationality.")
        if len(name) > 100 or len(nationality) > 50:
            raise ValueError("Name must be at most 100 characters; nationality at most 50.")
        with Session(self.engine) as session:
            session.add(Fighter(name=name, nationality=nationality))
            session.commit()

    def deleteFighter(self, fighter_id):
        with Session(self.engine) as session:
            fighter = session.get(Fighter, fighter_id)
            if fighter is None:
                raise ValueError("Fighter not found.")
            fight = session.scalars(select(Fight).where(
                or_(Fight.fighter_1 == fighter_id, Fight.fighter_2 == fighter_id))).first()
            if fight is not None:
                raise ValueError("This fighter is used in saved fights. Edit or delete those fights first.")
            session.delete(fighter)
            session.commit()

    #
    def saveFight(self, fight_id, event, fight_date, fighter_1, fighter_2, weight, result, method, round_number):
        event = event.strip()
        if not event or len(event) > 100:
            raise ValueError("Enter an event name of at most 100 characters.")
        if not isinstance(fight_date, date) or fight_date > date.today():
            raise ValueError("Choose a valid date for a completed fight.")
        if fighter_1 is None or fighter_2 is None:
            raise ValueError("Select two existing fighters.")
        if fighter_1 == fighter_2:
            raise ValueError("Select two different fighters.")
        if weight not in WEIGHTS or result not in RESULTS or method not in METHODS:
            raise ValueError("Select a weight class, result and method.")
        if type(round_number) is not int or not 1 <= round_number <= 5:
            raise ValueError("Round must be a whole number from 1 to 5.")
        with Session(self.engine) as session:
            if session.get(Fighter, fighter_1) is None or session.get(Fighter, fighter_2) is None:
                raise ValueError("Select two existing fighters.")
            if fight_id is None:
                fight = Fight()
            else:
                fight = session.get(Fight, fight_id)
            if fight is None:
                raise ValueError("Fight not found.")
            fight.event = event
            fight.fight_date = fight_date
            fight.fighter_1 = fighter_1
            fight.fighter_2 = fighter_2
            fight.weight = weight
            fight.result = result
            fight.method = method
            fight.round = round_number
            session.add(fight)
            session.commit()

    def deleteFight(self, fight_id):
        with Session(self.engine) as session:
            fight = session.get(Fight, fight_id)
            if fight is None:
                raise ValueError("Fight not found.")
            session.delete(fight)
            session.commit()

    def findFights(self, name="", weight="", method=""):
        query = select(Fight).order_by(Fight.id)
        if name.strip():
            fighter_ids = select(Fighter.id).where(Fighter.name.icontains(name.strip()))
            query = query.where(or_(Fight.fighter_1.in_(fighter_ids), Fight.fighter_2.in_(fighter_ids)))
        if weight:
            query = query.where(Fight.weight == weight)
        if method:
            query = query.where(Fight.method == method)
        with Session(self.engine) as session:
            return session.scalars(query).all()

# Dropdown Box
def choiceBox(placeholder, choices):
    box = QComboBox()
    box.addItems([placeholder] + choices)
    return box

# Interface/Inputs
class MainWindow(QMainWindow):
    def __init__(self, manager=None):
        super().__init__()
        self.manager = manager if manager is not None else FightManager()
        self.selected_id = None
        self.matches = []
        self.setWindowTitle("MMA Fight Results Tracker")
        self.resize(1180, 760)
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        forms = QHBoxLayout()
        fighter_form, fight_form, search_form = QFormLayout(), QFormLayout(), QFormLayout()
        self.name_input = QLineEdit()
        self.nationality_input = QLineEdit()
        self.fighters_text = QTextEdit()
        self.fighters_text.setReadOnly(True)
        fighter_form.addRow(QLabel("Add Fighter"))
        fighter_form.addRow("Name:", self.name_input)
        fighter_form.addRow("Nationality:", self.nationality_input)
        add_fighter = QPushButton("Add Fighter")
        add_fighter.clicked.connect(self.addFighter)
        fighter_form.addRow(add_fighter)
        fighter_form.addRow(self.fighters_text)
        self.delete_fighter_input = QComboBox()
        fighter_form.addRow(self.delete_fighter_input)
        delete_fighter = QPushButton("Delete Fighter")
        delete_fighter.clicked.connect(self.deleteFighter)
        fighter_form.addRow(delete_fighter)

        self.mode_label = QLabel("New Fight")
        self.event_input = QLineEdit()
        self.date_input = QDateEdit(QDate.currentDate())
        self.date_input.setCalendarPopup(True)
        self.date_input.setDisplayFormat("dd/MM/yyyy")
        self.date_input.setMaximumDate(QDate.currentDate())
        self.fighter_1 = QComboBox()
        self.fighter_2 = QComboBox()
        self.weight_input = choiceBox("Select weight class", WEIGHTS)
        self.result_input = choiceBox("Select result", RESULTS)
        self.method_input = choiceBox("Select method", METHODS)
        self.round_input = QSpinBox()
        self.round_input.setRange(1, 5)
        fight_form.addRow(self.mode_label)
        for label, widget in [("Event:", self.event_input), ("Date:", self.date_input),
                              ("Fighter 1:", self.fighter_1), ("Fighter 2:", self.fighter_2),
                              ("Weight class:", self.weight_input), ("Result:", self.result_input),
                              ("Method:", self.method_input), ("Round:", self.round_input)]:
            fight_form.addRow(label, widget)
        self.save_button = QPushButton("Add Fight")
        self.delete_button = QPushButton("Delete Fight")
        clear = QPushButton("Clear Form")
        for button, action in [(self.save_button, self.saveFight),
                               (self.delete_button, self.deleteFight), (clear, self.clearForm)]:
            button.clicked.connect(action)
            fight_form.addRow(button)

        self.search_input = QLineEdit()
        self.search_input.returnPressed.connect(self.applySearch)
        self.weight_filter = choiceBox("All weight classes", WEIGHTS)
        self.method_filter = choiceBox("All methods", METHODS)
        search_form.addRow(QLabel("Search Fights"))
        search_form.addRow("Fighter name:", self.search_input)
        search_form.addRow("Weight class:", self.weight_filter)
        search_form.addRow("Method:", self.method_filter)
        for text, action in [("Search / Filter", self.applySearch), ("Reset", self.resetSearch)]:
            button = QPushButton(text)
            button.clicked.connect(action)
            search_form.addRow(button)
        for form, stretch in [(fighter_form, 2), (fight_form, 3), (search_form, 2)]:
            forms.addLayout(form, stretch)
        layout.addLayout(forms)
        layout.addWidget(QLabel("Fight Summary - select a fight to edit or delete"))
        self.output = QListWidget()
        self.output.itemSelectionChanged.connect(self.selectFight)
        layout.addWidget(self.output)
        layout.addWidget(QLabel("Changes are saved automatically to mma_tracker.db."))
        self.clearForm()
        self.refresh()

    # Error Handling
    def tryAction(self, action, *args):
        try:
            action(*args)
        except (ValueError, SQLAlchemyError) as error:
            message = str(error) if isinstance(error, ValueError) else "Could not access the database. Please try again."
            QMessageBox.warning(self, "Action Failed", message)
            return False
        return True

    def addFighter(self):
        if self.tryAction(self.manager.addFighter, self.name_input.text(), self.nationality_input.text()):
            self.name_input.clear()
            self.nationality_input.clear()
            self.refresh()

    def deleteFighter(self):
        fighter_id = self.delete_fighter_input.currentData()
        if fighter_id is None:
            QMessageBox.warning(self, "Delete Fighter", "Select a fighter to delete.")
            return
        name = self.delete_fighter_input.currentText()
        answer = QMessageBox.question(self, "Delete Fighter", f"Delete {name}?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes and self.tryAction(self.manager.deleteFighter, fighter_id):
            self.refresh()

    def saveFight(self):
        chosen = self.date_input.date()
        if self.tryAction(self.manager.saveFight, self.selected_id, self.event_input.text(),
                          date(chosen.year(), chosen.month(), chosen.day()),
                          self.fighter_1.currentData(), self.fighter_2.currentData(),
                          self.weight_input.currentText(), self.result_input.currentText(),
                          self.method_input.currentText(), self.round_input.value()):
            self.clearForm()
            self.refresh()

    def deleteFight(self):
        if self.selected_id is None:
            return
        answer = QMessageBox.question(self, "Delete Fight", f"Delete fight {self.selected_id}?",
                                      QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer == QMessageBox.Yes and self.tryAction(self.manager.deleteFight, self.selected_id):
            self.clearForm()
            self.refresh()

    def selectFight(self):
        if not self.output.selectedItems():
            return
        fight = self.matches[self.output.currentRow()]
        self.selected_id = fight.id
        self.mode_label.setText(f"Editing Fight {fight.id}")
        self.event_input.setText(fight.event)
        self.date_input.setDate(QDate(fight.fight_date.year, fight.fight_date.month, fight.fight_date.day))
        self.fighter_1.setCurrentIndex(self.fighter_1.findData(fight.fighter_1))
        self.fighter_2.setCurrentIndex(self.fighter_2.findData(fight.fighter_2))
        self.weight_input.setCurrentText(fight.weight)
        self.result_input.setCurrentText(fight.result)
        self.method_input.setCurrentText(fight.method)
        self.round_input.setValue(fight.round)
        self.save_button.setText("Save Changes")
        self.delete_button.setEnabled(True)

    def refresh(self):
        fighters = {fighter.id: fighter for fighter in self.manager.getFighters()}
        self.fighters_text.setPlainText("\n".join(
            f"{f.id} | {f.name} | {f.nationality}" for f in fighters.values()))
        for box in [self.fighter_1, self.fighter_2, self.delete_fighter_input]:
            selected = box.currentData()
            box.clear()
            box.addItem("Select fighter", None)
            for fighter in fighters.values():
                box.addItem(f"{fighter.name} (ID {fighter.id})", fighter.id)
            box.setCurrentIndex(max(0, box.findData(selected)))
        weight = self.weight_filter.currentText() if self.weight_filter.currentIndex() else ""
        method = self.method_filter.currentText() if self.method_filter.currentIndex() else ""
        self.matches = self.manager.findFights(self.search_input.text(), weight, method)
        self.output.blockSignals(True)
        self.output.clear()
        for row, fight in enumerate(self.matches):
            first = fighters[fight.fighter_1].name
            second = fighters[fight.fighter_2].name
            self.output.addItem(f"{fight.id} | {fight.event} | {fight.fight_date} | {first} vs {second} | "
                                f"{fight.weight} | {fight.result} | {fight.method} | Round {fight.round}")
            if fight.id == self.selected_id:
                self.output.setCurrentRow(row)
        self.output.blockSignals(False)

    def clearForm(self):
        self.selected_id = None
        self.output.clearSelection()
        self.mode_label.setText("New Fight")
        self.event_input.clear()
        self.date_input.setDate(QDate.currentDate())
        for box in [self.fighter_1, self.fighter_2, self.weight_input, self.result_input, self.method_input]:
            box.setCurrentIndex(0)
        self.round_input.setValue(1)
        self.save_button.setText("Add Fight")
        self.delete_button.setEnabled(False)

    def applySearch(self):
        self.clearForm()
        self.refresh()

    def resetSearch(self):
        self.search_input.clear()
        self.weight_filter.setCurrentIndex(0)
        self.method_filter.setCurrentIndex(0)
        self.applySearch()

    def closeEvent(self, event):
        self.manager.engine.dispose()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    try:
        window = MainWindow()
    except SQLAlchemyError:
        QMessageBox.critical(None, "Database Error", "Could not open mma_tracker.db. Check that the folder is writable.")
        sys.exit(1)
    window.show()
    sys.exit(app.exec_())
