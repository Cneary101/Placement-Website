"""Exercise the real window using a temporary database and mocked dialogs."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import csv
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PyQt5.QtWidgets import QApplication, QMessageBox
from app import InternshipWindow
from database import TrackerDatabase

QT_APP = QApplication.instance() or QApplication([])
QT_APP.setStyle('Fusion')


class WindowTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.database = TrackerDatabase(Path(self.folder.name) / 'test.db')
        self.window = InternshipWindow(self.database)

    def tearDown(self):
        self.window.close()
        self.folder.cleanup()

    def fill_form(self):
        self.window.fields['company'].setText('Example Cloud')
        self.window.fields['role'].setText('Software Intern')
        self.window.fields['location'].setText('Athlone')
        self.window.status.setCurrentText('Applied')

    def test_add_select_update_and_reject_invalid_input(self):
        self.fill_form()
        self.window.add_button.click()
        self.assertEqual(self.window.table.rowCount(), 1)
        self.window.table.selectRow(0)
        self.assertTrue(self.window.update_button.isEnabled())
        self.assertFalse(self.window.add_button.isEnabled())
        self.window.status.setCurrentText('Interview')
        self.window.update_button.click()
        self.assertEqual(self.window.table.item(0, 2).text(), 'Interview')
        self.window.table.selectRow(0)
        self.window.fields['deadline'].setText('not a date')
        with patch('app.QMessageBox.warning') as warning:
            self.window.update_button.click()
            warning.assert_called_once()
        self.assertEqual(self.database.all_applications()[0]['deadline'], '')

    def test_filters_clear_selection_and_export_visible_records(self):
        self.fill_form()
        self.window.add_button.click()
        self.fill_form()
        self.window.fields['company'].setText('Sample QA')
        self.window.status.setCurrentText('Saved')
        self.window.add_button.click()
        self.window.table.selectRow(0)
        self.window.status_filter.setCurrentText('Applied')
        self.assertEqual(self.window.table.rowCount(), 1)
        self.assertIsNone(self.window.selected_id)
        output = Path(self.folder.name) / 'filtered.csv'
        with patch('app.QFileDialog.getSaveFileName', return_value=(str(output), 'CSV')):
            self.window.export_csv()
        with output.open(encoding='utf-8-sig', newline='') as file:
            rows = list(csv.DictReader(file))
        self.assertEqual([row['company'] for row in rows], ['Example Cloud'])
        self.window.search.setText('missing')
        self.assertEqual(self.window.table.rowCount(), 0)
        self.assertIn('Showing 0 of 2', self.window.count_label.text())

    def test_delete_can_be_cancelled_and_then_confirmed(self):
        self.fill_form()
        self.window.add_button.click()
        self.window.table.selectRow(0)
        with patch('app.QMessageBox.question', return_value=QMessageBox.No):
            self.window.delete_button.click()
        self.assertEqual(self.window.table.rowCount(), 1)
        with patch('app.QMessageBox.question', return_value=QMessageBox.Yes):
            self.window.delete_button.click()
        self.assertEqual(self.window.table.rowCount(), 0)
        self.assertFalse(self.window.delete_button.isEnabled())

    def test_job_link_opens_only_when_requested(self):
        self.fill_form()
        self.window.fields['job_link'].setText('https://example.com/internships')
        with patch('app.QDesktopServices.openUrl', return_value=True) as opened:
            self.window.open_button.click()
            opened.assert_called_once()
            self.assertEqual(opened.call_args.args[0].toString(), 'https://example.com/internships')


if __name__ == '__main__':
    unittest.main()
