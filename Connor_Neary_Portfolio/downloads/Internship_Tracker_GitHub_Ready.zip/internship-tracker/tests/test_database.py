"""Verify saved records, invalid input, filtering, deadlines and CSV output."""
import csv
import tempfile
import unittest
from datetime import date
from pathlib import Path
from database import (TrackerDatabase, application_summary, filter_applications,
                      export_applications, load_demo)


def application(**changes):
    values = {'company': 'Example Cloud', 'role': 'Software Intern', 'location': 'Athlone',
              'status': 'Saved', 'applied_date': '', 'deadline': '',
              'job_link': '', 'notes': ''}
    values.update(changes)
    return values


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.path = Path(self.folder.name) / 'applications.db'
        self.database = TrackerDatabase(self.path)

    def tearDown(self):
        self.database.close()
        self.folder.cleanup()

    def test_create_update_reopen_and_delete(self):
        identifier = self.database.add_application(application(company="O'Brien Software"))
        self.database.update_application(identifier, application(company="O'Brien Software", status='Interview', notes='Prepare questions'))
        self.database.close()
        self.database = TrackerDatabase(self.path)
        record = self.database.all_applications()[0]
        self.assertEqual((record['id'], record['status'], record['notes']), (identifier, 'Interview', 'Prepare questions'))
        self.database.delete_application(identifier)
        self.assertEqual(self.database.all_applications(), [])

    def test_invalid_changes_preserve_existing_record(self):
        identifier = self.database.add_application(application())
        cases = [application(company=' '), application(role=''),
                 application(status='Unknown'), application(deadline='2026-02-30'),
                 application(deadline='20261010'), application(job_link='file:///tmp/test'),
                 application(notes='x' * 4001)]
        for values in cases:
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    self.database.update_application(identifier, values)
                self.assertEqual(self.database.all_applications()[0]['status'], 'Saved')

    def test_sql_text_is_stored_as_data(self):
        name = "Example'); DROP TABLE applications; --"
        self.database.add_application(application(company=name))
        self.assertEqual(self.database.all_applications()[0]['company'], name)
        self.database.add_application(application())
        self.assertEqual(len(self.database.all_applications()), 2)

    def test_unknown_record_cannot_be_updated_or_deleted(self):
        with self.assertRaises(ValueError):
            self.database.update_application(999, application())
        with self.assertRaises(ValueError):
            self.database.delete_application(999)

    def test_search_and_status_work_together(self):
        self.database.add_application(application(company='First Employer', status='Applied'))
        self.database.add_application(application(company='Second Employer', status='Interview', location='Dublin'))
        records = self.database.all_applications()
        self.assertEqual(len(filter_applications(records, ' ATHLONE ', 'Applied')), 1)
        self.assertEqual(len(filter_applications(records, 'intern', 'Interview')), 1)
        self.assertEqual(filter_applications(records, 'missing'), [])

    def test_deadlines_include_boundaries_and_exclude_closed_applications(self):
        today = date(2026, 10, 8)
        for status, deadline in [('Saved', '2026-10-08'), ('Applied', '2026-10-15'),
                                 ('Interview', '2026-10-16'), ('Saved', '2026-10-07'),
                                 ('Offer', '2026-10-09'), ('Rejected', '2026-10-01')]:
            self.database.add_application(application(status=status, deadline=deadline))
        summary = application_summary(self.database.all_applications(), today)
        self.assertEqual((summary['due_soon'], summary['overdue'], summary['total']), (2, 1, 6))

    def test_csv_exports_filtered_records_and_multiline_notes(self):
        self.database.add_application(application(status='Applied', notes='First line\nSecond line'))
        self.database.add_application(application(status='Saved'))
        selected = filter_applications(self.database.all_applications(), status='Applied')
        output = Path(self.folder.name) / 'export.csv'
        export_applications(output, selected)
        with output.open(encoding='utf-8-sig', newline='') as file:
            rows = list(csv.DictReader(file))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['notes'], 'First line\nSecond line')

    def test_demo_is_separate_and_exports_quote_formula_like_text(self):
        demo = TrackerDatabase(':memory:')
        try:
            load_demo(demo, date(2026, 10, 8))
            self.assertEqual(len(demo.all_applications()), 6)
            self.assertEqual(self.database.all_applications(), [])
        finally:
            demo.close()
        self.database.add_application(application(notes='=1+1'))
        output = Path(self.folder.name) / 'export.csv'
        export_applications(output, self.database.all_applications())
        with output.open(encoding='utf-8-sig', newline='') as file:
            self.assertEqual(list(csv.DictReader(file))[0]['notes'], "'=1+1")


if __name__ == '__main__':
    unittest.main()
