"""A single PyQt5 window for recording and reviewing internship applications."""
import sqlite3
import sys
from pathlib import Path
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QFormLayout, QLabel, QLineEdit, QComboBox, QPlainTextEdit, QPushButton,
    QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView,
    QFileDialog, QMessageBox)
from database import (TrackerDatabase, STATUSES, filter_applications,
                      application_summary, export_applications, load_demo)


class InternshipWindow(QWidget):
    def __init__(self, database, demo=False):
        super().__init__()
        self.database = database
        self.selected_id = None
        self.visible_records = []
        self.setWindowTitle('Internship Application Tracker')
        self.resize(1180, 720)
        layout = QVBoxLayout(self)
        title = QLabel('Internship Application Tracker')
        font = title.font()
        font.setPointSize(16)
        font.setBold(True)
        title.setFont(font)
        layout.addWidget(title)
        label = 'Demo mode: fictional companies. Changes are temporary.' if demo else 'Your applications are saved locally on this computer.'
        layout.addWidget(QLabel(label))
        self.summary_label = QLabel()
        self.summary_label.setWordWrap(True)
        layout.addWidget(self.summary_label)

        body = QHBoxLayout()
        layout.addLayout(body, 1)
        left = QVBoxLayout()
        body.addLayout(left, 2)
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText('Search company, role or location')
        self.search.setAccessibleName('Search applications')
        self.status_filter = QComboBox()
        self.status_filter.addItems(['All statuses'] + STATUSES)
        self.status_filter.setAccessibleName('Filter by status')
        filters.addWidget(self.search, 2)
        filters.addWidget(self.status_filter, 1)
        left.addLayout(filters)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['Company', 'Role', 'Status', 'Deadline', 'Location'])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        for column in [2, 3, 4]:
            self.table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        left.addWidget(self.table, 1)
        self.count_label = QLabel()
        left.addWidget(self.count_label)
        export_button = QPushButton('Export visible rows to CSV')
        export_button.clicked.connect(self.export_csv)
        left.addWidget(export_button)

        right = QVBoxLayout()
        body.addLayout(right, 1)
        self.editor_title = QLabel('New application')
        right.addWidget(self.editor_title)
        form = QFormLayout()
        right.addLayout(form)
        self.fields = {}
        for key, label in [('company', 'Company *'), ('role', 'Role *'), ('location', 'Location')]:
            self.fields[key] = QLineEdit()
            form.addRow(label, self.fields[key])
        self.status = QComboBox()
        self.status.addItems(STATUSES)
        form.addRow('Status', self.status)
        for key, label in [('applied_date', 'Applied on'), ('deadline', 'Deadline'), ('job_link', 'Job link')]:
            self.fields[key] = QLineEdit()
            if key in ['applied_date', 'deadline']:
                self.fields[key].setPlaceholderText('YYYY-MM-DD or blank')
            else:
                self.fields[key].setPlaceholderText('https://... or blank')
            form.addRow(label, self.fields[key])
        right.addWidget(QLabel('Notes'))
        self.notes = QPlainTextEdit()
        self.notes.setPlaceholderText('Next action, interview preparation or other details')
        self.notes.setAccessibleName('Application notes')
        right.addWidget(self.notes, 1)
        self.add_button = QPushButton('Add application')
        self.update_button = QPushButton('Update selected')
        self.delete_button = QPushButton('Delete selected')
        self.clear_button = QPushButton('Clear form')
        self.open_button = QPushButton('Open job link')
        for button, handler in [(self.add_button, self.add_application),
                                (self.update_button, self.update_application),
                                (self.delete_button, self.delete_application),
                                (self.clear_button, self.clear_form),
                                (self.open_button, self.open_job_link)]:
            button.clicked.connect(handler)
            right.addWidget(button)
        self.message = QLabel()
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        self.table.itemSelectionChanged.connect(self.select_application)
        self.search.textChanged.connect(self.refresh)
        self.status_filter.currentTextChanged.connect(self.refresh)
        self.refresh()

    def refresh(self):
        records = self.database.all_applications()
        summary = application_summary(records)
        self.summary_label.setText(
            f"Total: {summary['total']}    Applied: {summary['applied']}    Interviews: {summary['interviews']}    "
            f"Offers: {summary['offers']}    Due in 7 days: {summary['due_soon']}    Overdue: {summary['overdue']}")
        self.visible_records = filter_applications(records, self.search.text(), self.status_filter.currentText())
        self.table.blockSignals(True)
        self.table.clearSelection()
        self.table.setRowCount(len(self.visible_records))
        for row, record in enumerate(self.visible_records):
            for column, field in enumerate(['company', 'role', 'status', 'deadline', 'location']):
                item = QTableWidgetItem(record[field])
                item.setToolTip(record[field])
                self.table.setItem(row, column, item)
        self.table.blockSignals(False)
        self.count_label.setText(f'Showing {len(self.visible_records)} of {len(records)} applications. Summary counts use all records.')
        self.clear_form()

    def form_values(self):
        values = {}
        for key, widget in self.fields.items():
            values[key] = widget.text()
        values['status'] = self.status.currentText()
        values['notes'] = self.notes.toPlainText()
        return values

    def clear_form(self):
        self.selected_id = None
        self.table.blockSignals(True)
        self.table.clearSelection()
        self.table.blockSignals(False)
        for widget in self.fields.values():
            widget.clear()
        self.status.setCurrentIndex(0)
        self.notes.clear()
        self.editor_title.setText('New application')
        self.add_button.setEnabled(True)
        self.update_button.setEnabled(False)
        self.delete_button.setEnabled(False)
        self.message.setText('Company and role are required. Select a table row to edit an existing application.')

    def select_application(self):
        row = self.table.currentRow()
        if not self.table.selectedItems() or row < 0:
            return
        record = self.visible_records[row]
        self.selected_id = record['id']
        for key, widget in self.fields.items():
            widget.setText(record[key])
        self.status.setCurrentText(record['status'])
        self.notes.setPlainText(record['notes'])
        self.editor_title.setText(f"Editing application {record['id']}")
        self.add_button.setEnabled(False)
        self.update_button.setEnabled(True)
        self.delete_button.setEnabled(True)
        self.message.setText('Change the fields and use Update selected to save your changes.')

    def add_application(self):
        try:
            self.database.add_application(self.form_values())
        except (ValueError, sqlite3.Error) as error:
            QMessageBox.warning(self, 'Could not add application', str(error))
            return
        self.refresh()
        self.message.setText('Application added. Active filters still apply to the table.')

    def update_application(self):
        if self.selected_id is None:
            return
        try:
            self.database.update_application(self.selected_id, self.form_values())
        except (ValueError, sqlite3.Error) as error:
            QMessageBox.warning(self, 'Could not update application', str(error))
            return
        self.refresh()
        self.message.setText('Application updated.')

    def delete_application(self):
        if self.selected_id is None:
            return
        name = self.fields['company'].text()
        answer = QMessageBox.question(self, 'Delete application',
            f'Delete the selected application for {name}?',
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if answer != QMessageBox.Yes:
            return
        try:
            self.database.delete_application(self.selected_id)
        except (ValueError, sqlite3.Error) as error:
            QMessageBox.warning(self, 'Could not delete application', str(error))
            return
        self.refresh()
        self.message.setText('Application deleted.')

    def export_csv(self):
        filename, _ = QFileDialog.getSaveFileName(self, 'Export visible applications',
                                                 'applications.csv', 'CSV files (*.csv)')
        if filename:
            try:
                export_applications(filename, self.visible_records)
            except OSError as error:
                QMessageBox.warning(self, 'Could not export', str(error))
                return
            self.message.setText(f'Exported {len(self.visible_records)} applications to {Path(filename).name}.')

    def open_job_link(self):
        from database import validate_application
        try:
            values = validate_application(self.form_values())
        except ValueError as error:
            QMessageBox.warning(self, 'Check the application', str(error))
            return
        if not values['job_link']:
            self.message.setText('Add a job link first.')
        elif not QDesktopServices.openUrl(QUrl(values['job_link'])):
            QMessageBox.warning(self, 'Could not open link', 'Your browser could not open the job link.')

    def closeEvent(self, event):
        self.database.close()
        event.accept()


if __name__ == '__main__':
    demo = '--demo' in sys.argv
    path = ':memory:' if demo else Path(__file__).parent / 'data' / 'applications.db'
    application = QApplication([sys.argv[0]])
    application.setStyle('Fusion')
    database = TrackerDatabase(path)
    if demo:
        load_demo(database)
    window = InternshipWindow(database, demo=demo)
    window.show()
    sys.exit(application.exec_())
