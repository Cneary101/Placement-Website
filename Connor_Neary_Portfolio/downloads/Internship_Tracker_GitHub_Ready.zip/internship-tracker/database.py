"""Validation, local SQLite storage and reporting for internship applications."""
import csv
import sqlite3
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import urlsplit

STATUSES = ['Saved', 'Applied', 'Interview', 'Offer', 'Rejected', 'Withdrawn']
FIELDS = ['company', 'role', 'location', 'status', 'applied_date',
          'deadline', 'job_link', 'notes']
ACTIVE_STATUSES = ['Saved', 'Applied', 'Interview']


def validate_application(values):
    """Clean input and reject incomplete names, invalid dates and invalid links."""
    cleaned = {}
    for field in FIELDS:
        cleaned[field] = values.get(field, '').strip()
    if not cleaned['company'] or not cleaned['role']:
        raise ValueError('Company and role are required.')
    if cleaned['status'] not in STATUSES:
        raise ValueError('Choose a valid application status.')
    for field in ['applied_date', 'deadline']:
        if cleaned[field]:
            try:
                parsed = date.fromisoformat(cleaned[field])
            except ValueError:
                raise ValueError('Dates must use YYYY-MM-DD, or be blank.') from None
            if parsed.isoformat() != cleaned[field]:
                raise ValueError('Dates must use YYYY-MM-DD, or be blank.')
    if cleaned['job_link']:
        link = cleaned['job_link']
        parsed = urlsplit(link)
        if parsed.scheme not in ['http', 'https'] or not parsed.hostname or any(c.isspace() for c in link):
            raise ValueError('Job links must be a valid http:// or https:// address.')
    limits = {'company': 120, 'role': 160, 'location': 120,
              'job_link': 2000, 'notes': 4000}
    for field, limit in limits.items():
        if len(cleaned[field]) > limit:
            raise ValueError(f'{field.replace("_", " ").title()} is too long (maximum {limit} characters).')
    return cleaned


class TrackerDatabase:
    """One table stores a person's applications; each row has a stable ID."""
    def __init__(self, path):
        if str(path) != ':memory:':
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(str(path))
        self.connection.row_factory = sqlite3.Row
        self.connection.execute('''CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL, role TEXT NOT NULL, location TEXT NOT NULL,
            status TEXT NOT NULL CHECK (status IN
                ('Saved','Applied','Interview','Offer','Rejected','Withdrawn')),
            applied_date TEXT NOT NULL, deadline TEXT NOT NULL,
            job_link TEXT NOT NULL, notes TEXT NOT NULL
        )''')
        self.connection.commit()

    def all_applications(self):
        rows = self.connection.execute('SELECT * FROM applications ORDER BY id DESC').fetchall()
        return [dict(row) for row in rows]

    def add_application(self, values):
        values = validate_application(values)
        with self.connection:
            cursor = self.connection.execute('''INSERT INTO applications
                (company, role, location, status, applied_date, deadline, job_link, notes)
                VALUES (:company, :role, :location, :status, :applied_date, :deadline, :job_link, :notes)''', values)
        return cursor.lastrowid

    def update_application(self, application_id, values):
        values = validate_application(values)
        values['id'] = application_id
        with self.connection:
            cursor = self.connection.execute('''UPDATE applications SET
                company=:company, role=:role, location=:location, status=:status,
                applied_date=:applied_date, deadline=:deadline, job_link=:job_link, notes=:notes
                WHERE id=:id''', values)
            if cursor.rowcount != 1:
                raise ValueError('This application no longer exists.')

    def delete_application(self, application_id):
        with self.connection:
            cursor = self.connection.execute('DELETE FROM applications WHERE id=?', (application_id,))
            if cursor.rowcount != 1:
                raise ValueError('This application no longer exists.')

    def close(self):
        self.connection.close()


def filter_applications(records, search='', status='All statuses'):
    results = []
    search = search.strip().lower()
    for record in records:
        text = ' '.join([record['company'], record['role'], record['location']]).lower()
        if search in text and (status == 'All statuses' or record['status'] == status):
            results.append(record)
    return results


def application_summary(records, today=None):
    today = today or date.today()
    summary = {'total': len(records), 'applied': 0, 'interviews': 0,
               'offers': 0, 'due_soon': 0, 'overdue': 0}
    for record in records:
        if record['status'] == 'Applied':
            summary['applied'] += 1
        if record['status'] == 'Interview':
            summary['interviews'] += 1
        if record['status'] == 'Offer':
            summary['offers'] += 1
        if record['deadline'] and record['status'] in ACTIVE_STATUSES:
            deadline = date.fromisoformat(record['deadline'])
            if today <= deadline <= today + timedelta(days=7):
                summary['due_soon'] += 1
            if deadline < today:
                summary['overdue'] += 1
    return summary


def export_applications(path, records):
    """Export the currently visible records. Quote formula-like text for spreadsheets."""
    with open(path, 'w', newline='', encoding='utf-8-sig') as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        for record in records:
            row = {}
            for field in FIELDS:
                value = record[field]
                if value.lstrip().startswith(('=', '+', '-', '@')):
                    value = "'" + value
                row[field] = value
            writer.writerow(row)


def load_demo(database, today=None):
    """Seed a separate demo database with fictional companies and relative dates."""
    today = today or date.today()
    examples = [
        ('Example Cloud', 'Software Development Intern', 'Athlone', 'Applied', 3,
         'CV submitted. Check the advertised role details before following up.'),
        ('Sample Data', 'Data Intern', 'Dublin', 'Interview', 12,
         'Practise explaining the Power BI dashboard and its data model.'),
        ('Practice Software', 'Python Intern', 'Remote', 'Saved', -1,
         'Fictional expired listing to demonstrate the overdue count.'),
        ('Example Systems', 'Backend Intern', 'Galway', 'Offer', 15,
         'Fictional offer. Review the role and placement requirements.'),
        ('Sample QA', 'QA Intern', 'Limerick', 'Applied', 6,
         'Prepare an example of input validation and application testing.'),
        ('Demo Analytics', 'BI Intern', 'Dublin', 'Rejected', 2,
         'Keep the record for reference; continue with other applications.')
    ]
    for company, role, location, status, offset, notes in examples:
        database.add_application({
            'company': company, 'role': role, 'location': location, 'status': status,
            'applied_date': '' if status == 'Saved' else (today - timedelta(days=4)).isoformat(),
            'deadline': (today + timedelta(days=offset)).isoformat(),
            'job_link': 'https://example.com/internships', 'notes': notes
        })
