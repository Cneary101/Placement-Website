# Internship Tracker Code Explanation

The project records internship applications in one local desktop window. Its useful functions are adding and changing records, searching, tracking status and deadlines, keeping data between sessions and exporting records. The interface uses ordinary PyQt5 widgets, like the earlier gym application.

This guide is separate from the runnable project bundle. Use it to understand the code and practise making your own changes before discussing implementation details with employers. 

## Read the project in this order

1. Run `python app.py --demo` and try the buttons with fictional records.
2. Read `validate_application` and `TrackerDatabase` in `database.py`.
3. Read `InternshipWindow.__init__`, then trace one button handler in `app.py`.
4. Read the filtering, summary and export functions.
5. Run the existing tests and change a small feature yourself.

## database.py

| Block | What it does | Why it is there |
| --- | --- | --- |
| Imports | Loads CSV, SQLite, date, path and URL helpers from Python's standard library. | The application needs one external package, PyQt5. SQLite does not need a separate server. |
| `STATUSES` and `FIELDS` | Define allowed statuses and the record fields in ordinary lists. | The GUI and storage use the same names. |
| `validate_application` | Copies input to a dictionary, trims whitespace, checks company and role, validates status, dates and links, and checks text lengths. | Invalid input is rejected before a database change is committed. Empty dates mean no date was recorded. |
| `TrackerDatabase.__init__` | Creates the data folder, opens SQLite and creates the applications table if it is missing. | Existing data is retained between sessions. `sqlite3.Row` allows access by column name. |
| `all_applications` | Selects rows with the newest IDs first and converts each row to a dictionary. | The GUI receives ordinary Python values rather than database cursors. |
| `add_application` | Validates values, inserts a row and returns its generated ID. | SQLite gives each application a stable identifier, even if names are repeated. |
| `update_application` | Validates values and changes only the row with the selected ID. | Editing a company name does not change which record is being edited. |
| `delete_application` | Deletes a row using its ID. | The GUI asks for confirmation before this method is called. |
| `close` | Closes the database connection. | The window calls it when the application closes. |
| `filter_applications` | Loops through records, matches lowercase search text and applies the status choice. | It is a small, readable way to combine filters for a personal list of applications. |
| `application_summary` | Counts current statuses and compares active deadlines with today's date. | Summary counts use all records, while the table can show a filtered subset. |
| `export_applications` | Writes column headings and the supplied records to CSV. | The GUI passes its visible records, so exported rows match the current filters. Formula-like text gets an apostrophe prefix for spreadsheet use. |
| `load_demo` | Adds six fictional records to the supplied demo database. | Screenshots and practice do not require real employer or personal information. |

### The SQLite table

Each application stores `id`, `company`, `role`, `location`, `status`, `applied_date`, `deadline`, `job_link` and `notes`. There is one table because this version only needs a record for each application. A second company table would be useful if repeated company information became difficult to maintain, but it adds a relationship that this version does not need.

The dates are stored as ISO text, for example `2026-10-14`. Python validates them with `date.fromisoformat` and checks that the value matches the required `YYYY-MM-DD` format.

`VALUES (:company, :role, ...)` uses named parameters. The data dictionary supplies values separately from the SQL statement. This also handles ordinary input such as an apostrophe in a company name. The delete query uses `?` with a one-item tuple; this is another supported form of bound parameter.

`with self.connection` commits successful changes and rolls back if an exception occurs. `cursor.rowcount` checks that an update or delete affected a real record. The table's status constraint provides another check at the database layer. `CREATE TABLE IF NOT EXISTS` keeps an existing table, but does not migrate it if the schema changes later.

## app.py

| Block | What it does | Why it is there |
| --- | --- | --- |
| Imports | Loads PyQt5 widgets, the database helpers and local path utilities. | The interface calls the logic in the other file. |
| `InternshipWindow.__init__` | Builds the title, summary, filters, read-only table, editing form and buttons; connects signals to handlers. | One window makes the project easy to use and explain. |
| `refresh` | Reads records, calculates the summary, filters table rows and clears the editing selection. | After a change, the display is rebuilt from saved data. The editor cannot accidentally refer to a row hidden by a new filter. |
| `form_values` | Reads text, the selected status and notes into a dictionary. | Add and update can use the same input structure. |
| `clear_form` | Clears the fields and ID, enables Add and disables Update/Delete. | New-record mode has no selected existing record. |
| `select_application` | Loads the selected row's saved values and ID into the editor. | Existing-record mode enables Update/Delete and disables Add. |
| `add_application` | Passes form values to the database, handles errors and refreshes. | Validation errors leave the saved records unchanged and show a message. |
| `update_application` | Uses the selected ID with the edited values. | Only the chosen row changes. |
| `delete_application` | Asks Yes/No, then deletes the selected ID when confirmed. | A cancelled deletion keeps the record. |
| `export_csv` | Opens a save dialog and exports visible rows. | The user chooses the output file. Cancelling the dialog writes nothing. |
| `open_job_link` | Validates the form's link and asks the default browser to open it. | It happens only after the user presses the button. |
| `closeEvent` | Closes the database and accepts the window-close event. | The connection is released when the application exits. |
| Main block | Creates QApplication, chooses a normal or demo database, builds the window and starts the event loop. | Normal runs save data; `--demo` uses temporary in-memory records. |

### Trace one complete action

The user selects a row. `select_application` stores its ID and fills the form. The user changes status to Interview and presses Update selected. `form_values` returns the text and status. `update_application` passes them and the selected ID to the database. Validation runs, SQLite commits the update, and `refresh` reloads the table and summary. If the deadline is invalid, the handler shows a warning and the previously saved record remains unchanged.

### Why the interface is read-only in the table

Editing happens through the form and an explicit save button. Clicking a table cell selects the application. It cannot silently change a displayed value without saving that change to SQLite.

## What the three screenshots prove

- **Overview:** six fictional applications with several statuses, total counts and deadline counts. The empty form is ready for another application.
- **Application details:** selecting Sample Data loads its role, status, dates, link and notes into the form. Update and Delete become available.
- **Filtering and export:** searching Athlone and choosing Applied leaves one matching row. The summary still describes all six records. The message confirms that this visible record was exported.

The screenshots were rendered from the actual PyQt5 window on Linux. They show fictional demonstrations, not applications Connor has submitted or real interview offers.

## Verification

The 12 tests passed on 8 October 2026. Database tests use temporary files and explicitly close and reopen SQLite to check persistence. GUI tests exercise the real widgets, mock file dialogs and confirmation prompts, and mock browser opening so they do not visit a website. Screenshots verify the final layout separately. Windows installation and display should still be checked on Connor's own computer before a live interview demonstration.

## Explain these concepts before an interview

The familiar parts are Python functions, dictionaries, lists, loops, exceptions, classes and PyQt5 widgets. The additions to study are SQLite's Python API, bound SQL parameters, transaction handling, `sqlite3.Row`, date comparison, `QDesktopServices` and the basics of `unittest.mock`.

Useful questions to practise:

- Why does the application use an ID instead of the company name when updating?
- What happens when a user enters an invalid date?
- Why do summary counts stay the same when a search filter changes?
- What information is included in a CSV export?
- How does demo mode avoid changing personal records?
- Why is one table sufficient for the current version?

## Small changes to make personally

Choose one change, run the app before and after it, and record what you changed and why. Sensible examples are adding an interview-date field, adding a simple sort choice, or adding a button that clears both filters. An interview-date field needs both a table/schema decision and changes to the form, validation, export and tests; it is a useful exercise once the current flow makes sense.

An honest introduction is: "My main portfolio project is an internship tracker. It stores application records in SQLite and combines CRUD, filters, deadline counts and CSV export. I can show you the current features and explain the parts I've worked through." Adjust the last sentence to match your actual preparation.

## Scope of this version

It is a local tool for one person. It does not send applications, scrape jobs, email reminders or synchronise between devices. There is no cloud deployment or authentication. Data files must be backed up separately. The simple structure is intended for a small personal list; large datasets or shared usage would call for a different design.
