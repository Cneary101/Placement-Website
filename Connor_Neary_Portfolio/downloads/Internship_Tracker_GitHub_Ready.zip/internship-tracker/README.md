# Internship Application Tracker

A small Python desktop application for organising internship applications. It combines a local database, a simple editing form, search and status filters, deadline counts and CSV export.

![Editing a fictional application in the working desktop app](docs/application-details.png)

## Features

- Add, edit and delete applications.
- Record company, role, location, status, application date, deadline, job link and notes.
- Search by company, role or location, and filter by status.
- Review total applications, status counts, deadlines within seven days and overdue deadlines.
- Keep records between sessions using SQLite.
- Export the visible records to CSV and open a saved job link in your browser.
- Try a separate demo using fictional records; demo changes do not affect your own database.

## Run on Windows

Use Python 3.12 or a compatible Python 3 installation. Extract the ZIP first, then open a terminal in the `internship-tracker` folder:

```text
py -3 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

For the fictional demonstration:

```text
python app.py --demo
```

For later use, activate the same environment and run `python app.py`, or use `start.bat`. On macOS/Linux, create the environment with `python3 -m venv .venv`, activate it with `source .venv/bin/activate`, then use the same pip and app commands. `sh start.sh --demo` runs the demo when dependencies are installed.

## Use the application

1. Fill in company and role; other fields are optional except the status.
2. Press **Add application**. New records appear at the top of the table.
3. Select a row to edit it, then press **Update selected**. **Clear form** returns to adding a new record.
4. **Delete selected** asks for confirmation.
5. Search and status filters work together. Changing a filter clears the editor selection; save edits before changing filters.
6. **Export visible rows to CSV** exports the filtered results. Clear both filters to export everything.

Dates use `YYYY-MM-DD` and can be blank. Statuses are Saved, Applied, Interview, Offer, Rejected and Withdrawn. Counts describe current statuses, not historical conversion rates. Deadline counts apply only to Saved, Applied and Interview records; today through seven days ahead is due soon, and dates before today are overdue. Summary counts always use all saved records, even when the table is filtered.

## Files and storage

`app.py` contains one window class and its event handlers. `database.py` contains the database class, input validation, filtering, summaries, CSV export and fictional demo records. SQLite queries use bound parameters so form input remains data.

Normal mode creates `data/applications.db` beside the application. Back up that file while the application is closed. Demo mode uses a separate in-memory database and resets when closed. `.gitignore` excludes personal databases, Python caches, virtual environments and the default exported CSV filename. Keep any other exports containing personal information out of the repository too.

The project has one table because each row represents one application. A separate company table could be a later improvement if company details need to be shared across many roles. Version 1 is a local tool without accounts, reminders, cloud sync, automatic applications or job scraping.

## Screenshots

All screenshots are from the running PyQt5 window with fictional records. They were rendered on Linux; window decorations and fonts may differ on Windows.

- [Overview](docs/overview.png): saved applications and summary counts.
- [Application details](docs/application-details.png): selecting a record loads the editing form.
- [Filtering and export](docs/filtered-applications.png): a combined location search and status filter, followed by CSV export.
- [Example exported CSV](docs/sample-export.csv): the single fictional record from the filtering screenshot.

## Verify

```text
python -m unittest discover -s tests -v
```

All **12 automated checks passed on 8 October 2026**. They cover database persistence across reopening, CRUD, invalid input preserving existing records, parameterised SQL, unknown record IDs, combined filters, deadline boundaries, filtered CSV output, isolated demo data and desktop button flows. Browser opening is mocked during the tests.

Describe the code you have reviewed, changes you have made and checks you have personally run accurately when presenting it. A separate code explanation accompanies the project.
