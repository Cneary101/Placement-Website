package com.tus.gym.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tus.gym.dto.GymMember;

@Repository
public interface GymMemberRepository extends JpaRepository<GymMember, Long> {

}