package com.tus.gym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymMembershipApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymMembershipApplication.class, args);
		
		System.out.println("Membership is up and running");
	}

}
