package com.tus.gym.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tus.gym.dto.GymMember;
import com.tus.gym.exception.NotFoundException;
import com.tus.gym.repository.GymMemberRepository;

@RestController
public class GymMemberController {

	@Autowired
	private GymMemberRepository gymMemberRepository;

	//entry point
	@GetMapping("/")
	public String index() {
		return "<h2>This is a Spring Data JPA Gym Membership REST Application</h2>";
	}

	// get all gym members
	@GetMapping("/members")
	public List<GymMember> getGymMembers() {
		return gymMemberRepository.findAll();
	}

	//get member by id
	@GetMapping("/members/{id}")
	public ResponseEntity<GymMember> getGymMemberById(@PathVariable(value = "id") Long id)
			throws NotFoundException {

		Optional<GymMember> gymMember = gymMemberRepository.findById(id);

		if (gymMember.isPresent())
			return ResponseEntity.ok().body(gymMember.get());
		else
			throw new NotFoundException("This gym member was not found :: " + id);
	}

	//create new member
	@PostMapping("/members")
	public GymMember createGymMember(@RequestBody GymMember gymMember) {
		return gymMemberRepository.save(gymMember);
	}

	//update
	@PutMapping("/members/{id}")
	public ResponseEntity<GymMember> updateGymMember(@PathVariable(value = "id") Long id,
			@RequestBody GymMember gymMemberDetails) throws NotFoundException {

		Optional<GymMember> optionalGymMember = gymMemberRepository.findById(id);

		if (optionalGymMember.isPresent()) {
			GymMember gymMember = optionalGymMember.get();

			gymMember.setFirstName(gymMemberDetails.getFirstName());
			gymMember.setLastName(gymMemberDetails.getLastName());
			gymMember.setEmail(gymMemberDetails.getEmail());
			gymMember.setPhoneNumber(gymMemberDetails.getPhoneNumber());
			gymMember.setMembershipType(gymMemberDetails.getMembershipType());
			gymMember.setJoinDate(gymMemberDetails.getJoinDate());
			gymMember.setMonthlyFee(gymMemberDetails.getMonthlyFee());
			gymMember.setActive(gymMemberDetails.getActive());

			final GymMember updatedGymMember = gymMemberRepository.save(gymMember);
			return ResponseEntity.ok(updatedGymMember);
		} else {
			throw new NotFoundException("This gym member was not found :: " + id);
		}
	}

	//delete a member by id
	@DeleteMapping("/members/{id}")
	public void deleteGymMember(@PathVariable(value = "id") Long gymMemberId) {
		gymMemberRepository.deleteById(gymMemberId);
	}

}