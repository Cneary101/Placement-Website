//references for all controls in the script
var nameInput = document.getElementById("name-filter");
var capitalInput = document.getElementById("capital-filter");
var languageInput = document.getElementById("language-filter");
var currencyInput = document.getElementById("currency-filter");
var countrySelect = document.getElementById("country-select");
var detailsDiv = document.getElementById("country-details");
 // placeholder
var allCountries = [];  
var weatherChart = null; 

//load all countries when the page is ready
document.addEventListener("DOMContentLoaded", function () {
  loadCountries();
  //re-filter whenever the user types
  nameInput.addEventListener("input", applyFilters);
  capitalInput.addEventListener("input", applyFilters);
  languageInput.addEventListener("input", applyFilters);
  currencyInput.addEventListener("input", applyFilters);

  countrySelect.addEventListener("change", handleCountryChange);
});

// Get country data from RestCountries
function loadCountries() {
  fetch("https://restcountries.com/v3.1/all?fields=name,capital,region,latlng,flags,languages,currencies,cca2")
    .then(function (response) {  //check response
      if (!response.ok) {
        throw new Error("Could not load countries");  
      }
      return response.json();
    })
    // Sort + store alphabetically by name
    .then(function (data) {       
      data.sort(function (a, b) { 
        return a.name.common.localeCompare(b.name.common); 
      });
      allCountries = data;
      applyFilters(); 
    })
    //Error handling
    .catch(function (error) {
      countrySelect.innerHTML = "";
      var opt = document.createElement("option");  
      opt.textContent = "Error loading countries: " + error.message; 
      opt.disabled = true;  //prevents the user clicking on this option in the list
      countrySelect.appendChild(opt); 
    });
}

// Apply all text filters and update the country list
function applyFilters() {
  var name = nameInput.value.toLowerCase();
  var capital = capitalInput.value.toLowerCase();    
  var language = languageInput.value.toLowerCase();  
  var currency = currencyInput.value.toLowerCase();

  var filtered = [];  //empty array to fill with matched countries

  for (var i = 0; i < allCountries.length; i++) {
    var c = allCountries[i];
    
    //checks each filter one by one, only countries that fit all 4 filters are passed into the array

    // Name
    var nameText = c.name && c.name.common ? c.name.common.toLowerCase() : ""; 
    if (name && nameText.indexOf(name) === -1) {  
      continue;
    }

    // Capital
    var capitalText = "";
    if (c.capital && c.capital.length > 0) {
      capitalText = c.capital[0].toLowerCase();
    }
    if (capital && capitalText.indexOf(capital) === -1) {
      continue;
    }

    // Language (search all language names)
    var languageText = "";
    if (c.languages) {
      var langArray = Object.values(c.languages);
      languageText = langArray.join(" ").toLowerCase();
    }
    if (language && languageText.indexOf(language) === -1) {
      continue;
    }

    // Currency (search EUR, USD)
    var currencyText = "";
    if (c.currencies) {
      var codes = Object.keys(c.currencies);
      currencyText = codes.join(" ").toLowerCase();
    }
    if (currency && currencyText.indexOf(currency) === -1) {
      continue;
    }

    filtered.push(c);
  }
  //redraws the <select> with only necessary info
  renderCountryOptions(filtered);
}

//update the <select> with the given list
function renderCountryOptions(list) {
  countrySelect.innerHTML = "";

//handles case where no countrty matches filter
  if (list.length === 0) { 
    var opt = document.createElement("option");
    opt.textContent = "No countries match these filters.";
    opt.disabled = true;
    countrySelect.appendChild(opt);
    return;
  }

  for (var i = 0; i < list.length; i++) { 
    var c = list[i];

    var opt2 = document.createElement("option");
    opt2.value = c.cca2;            
    opt2.textContent = c.name.common; 
    countrySelect.appendChild(opt2);  
  }
}

//when a country is selected
function handleCountryChange() {
  var code = countrySelect.value;
  if (!code) 
    return;

  var country = null;
  for (var i = 0; i < allCountries.length; i++) {
    if (allCountries[i].cca2 === code) {
      country = allCountries[i];
      break;
    }
  }
  if (!country) 
    return;

  //display the <select> box and the chart
  showCountryDetails(country);
  loadWeather(country);
}

//show basic info about the country
function showCountryDetails(country) {
  var flagUrl = country.flags && country.flags.png ? country.flags.png : "";  
  var capital = (country.capital && country.capital[0]) ? country.capital[0] : "N/A";
  var region = country.region || "N/A"; 

  var languages = "N/A";
  if (country.languages) {
    languages = Object.values(country.languages).join(", ");
  }

  //Currencies are stored as an object keyed by code
  var currencies = "N/A";
  if (country.currencies) {
    var parts = [];
    for (var code in country.currencies) { 
      var info = country.currencies[code];
      parts.push(code + " (" + info.name + ")");  
    }
    currencies = parts.join(", ");  
  }

//flags
  var html = "";
  html += '<h4 style="margin-top:0;">';  
  if (flagUrl) {
    html += '<img src="' + flagUrl + '" alt="Flag of ' + country.name.common + '"> ';
  }
  html += country.name.common + "</h4>"; 
  //add rest of details
  html += "<p><strong>Capital:</strong> " + capital + "</p>";
  html += "<p><strong>Region:</strong> " + region + "</p>";
  html += "<p><strong>Languages:</strong> " + languages + "</p>";
  html += "<p><strong>Currencies:</strong> " + currencies + "</p>";
  html += '<p class="muted">Country code: ' + country.cca2 + "</p>";  //muted for less important information

  detailsDiv.innerHTML = html;
}

//get weather for the country from Open-Meteo
function loadWeather(country) {
  if (!country.latlng || country.latlng.length !== 2) {
    updateChart([], [], [], "No coordinates for this country"); 
    return;
  }

  var lat = country.latlng[0];
  var lon = country.latlng[1]; 

  var url =  //creates url for list of dates and the next 7 days of max/min weather
    "https://api.open-meteo.com/v1/forecast" +
    "?latitude=" + lat +
    "&longitude=" + lon +
    "&daily=temperature_2m_min,temperature_2m_max" +
    "&timezone=auto";

  fetch(url)
    .then(function (response) {
      if (!response.ok) {
        throw new Error("Could not load weather");
      }
      return response.json();
    })
    .then(function (data) {
      var labels = data.daily.time; 
      var mins = data.daily.temperature_2m_min;  
      var maxs = data.daily.temperature_2m_max;  
      updateChart(labels, mins, maxs, "7-day forecast for " + country.name.common);
    })
    .catch(function (error) {
      updateChart([], [], [], "Error loading weather: " + error.message);
    });
}

//draw or update the Chart.js line chart
function updateChart(labels, mins, maxs, titleText) {
  var canvas = document.getElementById("weather-chart"); 
  var ctx = canvas.getContext("2d"); 

  if (weatherChart) {
    weatherChart.destroy();
  }

  //no data case
  if (!labels || labels.length === 0) {
    weatherChart = new Chart(ctx, {
      type: "line",
      data: { labels: [], datasets: [] },
      options: {
        plugins: {
          title: { display: true, text: titleText || "No data" },
          legend: { display: false }
        }
      }
    });
    return;
  }

  //normal chart creation 
  weatherChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: labels,
      datasets: [
        {
          label: "Min Temp (°C)",
          data: mins,
          borderWidth: 2.5,
          tension: 0.3
        },
        {
          label: "Max Temp (°C)",
          data: maxs,
          borderWidth: 2.5,
          tension: 0.3
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: { display: true, text: titleText }
      },
      scales: {
        y: {
          title: { display: true, text: "Temperature (°C)" }
        }
      }
    }
  });
}