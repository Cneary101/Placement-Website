# Country Weather Dashboard

College web development assignment using HTML, CSS/W3CSS, JavaScript and Chart.js.

Open index.html in a browser. If the browser restricts local-file requests, use an editor's local server or run python -m http.server 8000 in this folder, then open http://localhost:8000.

Internet access is required for the stylesheet, font, Chart.js, REST Countries and Open-Meteo resources. The portfolio itself does not require these project dependencies.

The country list can be filtered by country name, capital, language and currency. Selecting a country shows its details and requests seven days of minimum and maximum temperatures using the supplied country coordinates.

The original HTML, CSS and JavaScript are unchanged. This source has not been rerun against the current external APIs during packaging; the portfolio screenshots come from the assignment report.
